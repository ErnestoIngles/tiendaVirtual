// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"; 
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyD18GSPWbYQsda5oyWxEOiuyRCuY7P8RmE",
  authDomain: "tiendavirtual-728a0.firebaseapp.com",
  projectId: "tiendavirtual-728a0",
  storageBucket: "tiendavirtual-728a0.firebasestorage.app",
  messagingSenderId: "410540735706",
  appId: "1:410540735706:web:30cdfaf2657899ca10b9e3",
  measurementId: "G-1C60WKHKN6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);